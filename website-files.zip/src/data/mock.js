// Mock data for the Chemical Recycling website

export const plasticProductionData = [
  { year: 1950, production: 2 },
  { year: 1960, production: 8 },
  { year: 1970, production: 30 },
  { year: 1980, production: 70 },
  { year: 1990, production: 120 },
  { year: 2000, production: 200 },
  { year: 2010, production: 300 },
  { year: 2015, production: 350 },
  { year: 2020, production: 400 },
  { year: 2025, production: 500 },
  { year: 2030, production: 600 },
];

export const industryClaimsVsResearch = {
  claims: [
    "Converts plastic waste into raw materials for new products",
    "Increases overall recycling rates",
    "Reduces plastic pollution",
    "Supports a circular economy",
    "Decreases need for new plastic production"
  ],
  research: [
    "Requires extremely high energy input",
    "Can release toxic by-products",
    "Limited evidence of large-scale effectiveness",
    "Does not significantly reduce new plastic production",
    "May prolong reliance on single-use plastics"
  ]
};

export const sources = [
  "OECD (Organisation for Economic Co-operation and Development)",
  "Natural Resources Defense Council (NRDC)",
  "American Chemistry Council",
  "Ragaert et al. (Academic Research)",
  "Global Alliance for Incinerator Alternatives (GAIA)",
  "United Nations Environment Programme"
];

export const keyFacts = [
  {
    stat: "400M+",
    label: "Tons of plastic produced annually"
  },
  {
    stat: "<10%",
    label: "Of plastic waste successfully recycled"
  },
  {
    stat: "70 years",
    label: "Of exponential plastic production growth"
  }
];

export const problemPoints = [
  "Global plastic production has increased dramatically over the past 70 years, from a few million tons in 1950 to over 400 million tons today",
  "Less than 10% of plastic waste is successfully recycled worldwide",
  "Conventional mechanical recycling methods can only recycle a limited range of plastics",
  "Negative environmental effects include microplastics polluting oceans, disturbed ecosystems, and health risks for communities",
  "Plastic waste volume will continue to grow substantially, compounding environmental and public health problems"
];

export const impactPoints = [
  {
    title: "High Energy Consumption",
    description: "Chemical recycling requires a large amount of energy and can emit significant greenhouse gases"
  },
  {
    title: "Toxic By-products",
    description: "The process often creates dangerous by-products that pose risks to people's health and the environment"
  },
  {
    title: "Environmental Justice",
    description: "Communities near waste processing plants often experience higher levels of pollution"
  },
  {
    title: "Root Cause Unaddressed",
    description: "Chemical recycling does not resolve the underlying cause: excessive production and consumption of single-use plastics"
  }
];

export const solutions = [
  {
    title: "Reduce Production",
    description: "Reduce overall production of single-use plastics",
    icon: "TrendingDown"
  },
  {
    title: "Promote Reusables",
    description: "Promote reusable and sustainable materials",
    icon: "Recycle"
  },
  {
    title: "Safe Waste Systems",
    description: "Invest in environmentally safe and community-conscious waste systems",
    icon: "Shield"
  }
];
