import React from 'react';
import { Leaf } from 'lucide-react';
import { sources } from '../data/mock';

export const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand Section */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Leaf className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-lg text-white">Rethinking Recycling</span>
            </div>
            <p className="text-sm text-gray-400">
              Transforming the future of plastic waste through smarter solutions
            </p>
          </div>

          {/* Sources Section */}
          <div className="md:col-span-2">
            <h3 className="font-semibold text-white mb-4">Research Sources</h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
              {sources.map((source, index) => (
                <li key={index} className="text-gray-400">
                  • {source}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-500">
          <p>© {new Date().getFullYear()} Rethinking Chemical Recycling. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
