import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { plasticProductionData } from '../data/mock';

export const PlasticProductionChart = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-xl font-bold text-gray-900 mb-4">
        Global Plastic Production Over Time
      </h3>
      <p className="text-sm text-gray-600 mb-6">
        Production in millions of tons per year
      </p>
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={plasticProductionData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="year" 
            stroke="#6b7280"
            style={{ fontSize: '14px' }}
          />
          <YAxis 
            stroke="#6b7280"
            style={{ fontSize: '14px' }}
            label={{ value: 'Million Tons', angle: -90, position: 'insideLeft' }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#fff', 
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              padding: '12px'
            }}
            formatter={(value) => [`${value} million tons`, 'Production']}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="production" 
            stroke="#2563eb" 
            strokeWidth={3}
            dot={{ fill: '#2563eb', r: 4 }}
            activeDot={{ r: 6 }}
            name="Plastic Production"
          />
        </LineChart>
      </ResponsiveContainer>
      <p className="text-xs text-gray-500 mt-4 italic">
        Fig 1: The dramatic increase in global plastic production from 1950 to projected 2030
      </p>
    </div>
  );
};
