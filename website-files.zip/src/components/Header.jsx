import React, { useState } from 'react';
import { Menu, X, Leaf } from 'lucide-react';
import { Button } from './ui/button';

export const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { path: '#home', label: 'Home' },
    { path: '#problem', label: 'The Problem' },
    { path: '#research', label: 'Research' },
    { path: '#impact', label: 'Impact' },
    { path: '#solutions', label: 'Solutions' }
  ];

  const scrollToSection = (e, path) => {
    e.preventDefault();
    const element = document.querySelector(path);
    if (element) {
      const offset = 80; // Header height
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <a href="#home" onClick={(e) => scrollToSection(e, '#home')} className="flex items-center space-x-2 group">
            <div className="bg-blue-600 p-2 rounded-lg group-hover:bg-blue-700 transition-colors">
              <Leaf className="h-6 w-6 text-white" />
            </div>
            <span className="font-bold text-xl text-gray-900 hidden sm:block">
              Rethinking Recycling
            </span>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <a
                key={link.path}
                href={link.path}
                onClick={(e) => scrollToSection(e, link.path)}
                className="px-4 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CTA Button */}
          <div className="hidden md:block">
            <a href="#solutions" onClick={(e) => scrollToSection(e, '#solutions')}>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Take Action
              </Button>
            </a>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-2">
              {navLinks.map((link) => (
                <a
                  key={link.path}
                  href={link.path}
                  onClick={(e) => scrollToSection(e, link.path)}
                  className="px-4 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                >
                  {link.label}
                </a>
              ))}
              <a href="#solutions" onClick={(e) => scrollToSection(e, '#solutions')}>
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white mt-2">
                  Take Action
                </Button>
              </a>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
