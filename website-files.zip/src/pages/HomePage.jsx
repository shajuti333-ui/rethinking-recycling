import React, { useState } from 'react';
import { ArrowRight, Leaf, TrendingUp, AlertTriangle, AlertCircle, CheckCircle, XCircle, Zap, Droplet, Users, TrendingDown, Recycle, Shield, Download, FileDown } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import { toast } from 'sonner';
import { PlasticProductionChart } from '../components/PlasticProductionChart';
import { keyFacts, problemPoints, industryClaimsVsResearch, impactPoints, solutions } from '../data/mock';
import html2pdf from 'html2pdf.js';

const HomePage = () => {
  const [formData, setFormData] = useState({
    name: '',
    organization: '',
    email: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);

  const iconMap = {
    TrendingDown: TrendingDown,
    Recycle: Recycle,
    Shield: Shield
  };

  const impactIconMap = {
    'High Energy Consumption': Zap,
    'Toxic By-products': Droplet,
    'Environmental Justice': Users,
    'Root Cause Unaddressed': AlertTriangle
  };

  const handleDownloadPDF = async () => {
    setIsGeneratingPDF(true);
    toast.info('Generating PDF... This may take a moment.');

    try {
      const element = document.getElementById('pdf-content');
      const opt = {
        margin: 0.5,
        filename: 'Rethinking-Chemical-Recycling.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, logging: false },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      await html2pdf().set(opt).from(element).save();
      toast.success('PDF downloaded successfully!');
    } catch (error) {
      console.error('PDF generation error:', error);
      toast.error('Failed to generate PDF. Please try again.');
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setSubmitted(true);
    toast.success('Thank you for your interest! We will be in touch soon.');
    
    setTimeout(() => {
      setFormData({ name: '', organization: '', email: '', message: '' });
      setSubmitted(false);
    }, 3000);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-blue-50">
      {/* PDF Export Button - Fixed Position */}
      <div className="fixed bottom-6 right-6 z-40">
        <Button
          onClick={handleDownloadPDF}
          disabled={isGeneratingPDF}
          className="bg-blue-600 hover:bg-blue-700 text-white shadow-2xl px-6 py-6 rounded-full"
          title="Download Website as PDF"
        >
          <FileDown className="h-6 w-6 mr-2" />
          {isGeneratingPDF ? 'Generating...' : 'Export as PDF'}
        </Button>
      </div>

      {/* Main Content for PDF */}
      <div id="pdf-content">
      {/* Hero Section */}
      <section id="home" className="relative overflow-hidden bg-gradient-to-br from-blue-100 to-blue-50">
        <div className="absolute inset-0 opacity-20">
          <img 
            src="https://images.unsplash.com/photo-1621451537084-482c73073a0f" 
            alt="Ocean pollution background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-blue-100 to-blue-50 opacity-90"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Leaf className="h-4 w-4 mr-2" />
              Environmental Advocacy
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Rethinking Chemical Recycling:
              <span className="text-blue-600"> A Better Path Forward</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              Transforming the future of plastic waste through smarter solutions
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href="#problem" onClick={(e) => {
                e.preventDefault();
                document.querySelector('#problem').scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg">
                  Explore the Issue
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </a>
              <a href="#solutions" onClick={(e) => {
                e.preventDefault();
                document.querySelector('#solutions').scrollIntoView({ behavior: 'smooth', block: 'start' });
              }}>
                <Button variant="outline" className="border-blue-600 text-blue-700 hover:bg-blue-50 px-8 py-6 text-lg">
                  View Solutions
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Key Facts Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {keyFacts.map((fact, index) => (
              <Card key={index} className="border-blue-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-8 text-center">
                  <div className="text-4xl md:text-5xl font-bold text-blue-600 mb-2">
                    {fact.stat}
                  </div>
                  <div className="text-gray-600 font-medium">
                    {fact.label}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Critical Issue
              </div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                The Challenge We Face
              </h2>
              <div className="prose prose-lg text-gray-600 space-y-4">
                <p>
                  Chemical recycling has been promoted as a possible technological solution to the plastic waste crisis, but studies show that it requires large amounts of energy and creates environmental damage through hazardous by-products.
                </p>
                <p>
                  Furthermore, chemical recycling does not address the root cause for the excessive amount of plastic being produced. Plastics are being produced in increasing amounts around the world, but our current recycling systems are unable to manage the increased pace of production.
                </p>
              </div>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-200">
              <div className="flex items-start space-x-4 mb-6">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <TrendingUp className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-2">Our Goal</h3>
                  <p className="text-gray-600">
                    Persuade industry leaders to move beyond chemical recycling and invest in more sustainable solutions
                  </p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-cyan-100 p-3 rounded-lg">
                  <Leaf className="h-6 w-6 text-cyan-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-2">Target Audience</h3>
                  <p className="text-gray-600">
                    Plastic and Chemical Industry Decision-Makers
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Problem Section */}
      <section id="problem" className="py-20 bg-white scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-12">
            <div>
              <div className="inline-flex items-center bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-medium mb-4">
                <AlertCircle className="h-4 w-4 mr-2" />
                Critical Issue
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                The Growing Plastic Waste Crisis
              </h2>
              <p className="text-xl text-gray-600">
                Understanding the scale and impact of global plastic production
              </p>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-xl">
              <img 
                src="https://images.pexels.com/photos/9034664/pexels-photo-9034664.jpeg" 
                alt="Beach plastic pollution"
                className="w-full h-80 object-cover"
              />
            </div>
          </div>

          {/* Chart */}
          <div className="mb-16">
            <PlasticProductionChart />
          </div>

          {/* Visual Impact */}
          <div className="mb-12 rounded-2xl overflow-hidden shadow-2xl">
            <img 
              src="https://images.pexels.com/photos/16884368/pexels-photo-16884368.jpeg" 
              alt="Plastic bottles pollution in water"
              className="w-full h-96 object-cover"
            />
          </div>

          {/* Problem Points */}
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Key Challenges
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {problemPoints.map((point, index) => (
              <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center font-bold">
                      {index + 1}
                    </div>
                    <p className="text-gray-700 leading-relaxed">
                      {point}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Research Section */}
      <section id="research" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50 scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              What Industry Claims vs. What Research Shows
            </h2>
            <p className="text-xl text-gray-600">
              Chemical recycling is frequently promoted as a solution to plastic waste, but research highlights important limitations that must be considered.
            </p>
          </div>

          {/* Comparison */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Industry Claims */}
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-blue-800 flex items-center">
                  <div className="bg-blue-600 p-2 rounded-lg mr-3">
                    <CheckCircle className="h-6 w-6 text-white" />
                  </div>
                  Industry Claims
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {industryClaimsVsResearch.claims.map((claim, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{claim}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Research Findings */}
            <Card className="border-red-200 bg-red-50">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-red-800 flex items-center">
                  <div className="bg-red-600 p-2 rounded-lg mr-3">
                    <XCircle className="h-6 w-6 text-white" />
                  </div>
                  Research Findings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4">
                  {industryClaimsVsResearch.research.map((finding, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <XCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{finding}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Key Insight */}
          <div className="bg-white p-8 md:p-12 rounded-2xl shadow-xl border-l-4 border-amber-500">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              The Critical Gap
            </h3>
            <p className="text-lg text-gray-600 leading-relaxed">
              There is a significant disconnect between what the industry promotes and what independent research has discovered. While chemical recycling may sound promising, the reality reveals major challenges in energy consumption, toxic emissions, and most importantly, it fails to address the root cause of plastic overproduction.
            </p>
          </div>
        </div>
      </section>

      {/* Impact Section */}
      <section id="impact" className="py-20 bg-white scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Environmental and Social Impacts
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Understanding the real consequences of chemical recycling technology
            </p>
            <p className="text-lg text-gray-600 leading-relaxed">
              Chemical recycling technology comes with major issues for the planet and society. It requires a large amount of energy, can emit greenhouse gases, and often creates dangerous by-products that pose risks to people's health and the earth.
            </p>
          </div>

          {/* Impact Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {impactPoints.map((impact, index) => {
              const IconComponent = impactIconMap[impact.title];
              return (
                <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-3">
                      <div className="bg-amber-100 p-3 rounded-lg">
                        <IconComponent className="h-6 w-6 text-amber-600" />
                      </div>
                      <span className="text-xl font-bold text-gray-900">{impact.title}</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 leading-relaxed">
                      {impact.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Environmental Justice */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-8 md:p-12 rounded-2xl shadow-lg mb-8">
            <div className="flex items-start space-x-4">
              <div className="bg-blue-600 p-3 rounded-lg">
                <Users className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                  Communities Bear the Burden
                </h3>
                <p className="text-lg text-gray-600 leading-relaxed">
                  Communities near waste processing plants often experience higher levels of pollution, raising environmental justice concerns. The impact of chemical recycling facilities disproportionately affects vulnerable populations, creating health and environmental inequities.
                </p>
              </div>
            </div>
          </div>

          {/* Core Issue */}
          <div className="bg-red-50 p-8 md:p-12 rounded-2xl border-2 border-red-200">
            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              The Fundamental Problem
            </h3>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Chemical recycling does not resolve the underlying cause: excessive production and consumption of single-use plastics. The best way to address these problems is to reduce plastic production and consumption, utilize more sustainable products, and create safer waste management systems.
            </p>
            <p className="text-lg font-semibold text-gray-900">
              Given these limitations, alternative strategies must be considered.
            </p>
          </div>
        </div>
      </section>

      {/* Solutions Section */}
      <section id="solutions" className="py-20 bg-gradient-to-br from-blue-50 to-blue-100 scroll-mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <div className="inline-flex items-center bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium mb-6">
              <CheckCircle className="h-4 w-4 mr-2" />
              Sustainable Path Forward
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              A More Sustainable Path Forward
            </h2>
            <p className="text-xl text-gray-600">
              Industry leaders should focus less on chemical recycling as a primary means and more on implementing strategies that address the underlying problems of plastic waste.
            </p>
          </div>

          {/* Solutions Visual */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1669384537216-24740a56a2d5" 
                alt="Please Recycle message"
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1604187351574-c75ca79f5807" 
                alt="Blue recycling bin"
                className="w-full h-48 object-cover"
              />
            </div>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.pexels.com/photos/3850561/pexels-photo-3850561.jpeg" 
                alt="Green recycling symbol"
                className="w-full h-48 object-cover"
              />
            </div>
          </div>

          {/* Solutions Cards */}
          <h3 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Key Solutions
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {solutions.map((solution, index) => {
              const IconComponent = iconMap[solution.icon];
              return (
                <Card key={index} className="border-blue-200 hover:shadow-xl transition-shadow bg-white">
                  <CardHeader>
                    <div className="bg-blue-600 w-14 h-14 rounded-lg flex items-center justify-center mb-4">
                      <IconComponent className="h-7 w-7 text-white" />
                    </div>
                    <CardTitle className="text-xl font-bold text-gray-900">
                      {solution.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 leading-relaxed">
                      {solution.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Benefits */}
          <div className="bg-white p-8 md:p-12 rounded-2xl shadow-lg mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
              Long-Term Benefits
            </h3>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              Activities like reducing single-use products, developing reusable material alternatives, and constructing safer community-based waste disposal systems can provide long-term benefits.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Industries should view chemical recycling as just an option, but prioritize addressing root problems by preventing single-use plastics, investing in sustainable materials, and safer waste disposal systems, while maintaining financial success.
            </p>
          </div>

          {/* PDF Download Section */}
          <div className="bg-gradient-to-br from-blue-100 to-cyan-100 p-8 rounded-2xl shadow-lg mb-12 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Download Our Complete Study Guide
            </h3>
            <p className="text-gray-700 mb-6">
              Get the full research report with all data, sources, and recommendations in PDF format
            </p>
            <a 
              href="https://customer-assets.emergentagent.com/job_6096721a-fe54-452f-b68f-64f18e83c2d2/artifacts/b0u46bv5_Study%20guide-3.pdf"
              target="_blank"
              rel="noopener noreferrer"
              download="Rethinking-Chemical-Recycling-Study-Guide.pdf"
            >
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg">
                <Download className="mr-2 h-5 w-5" />
                Download PDF Study Guide
              </Button>
            </a>
          </div>

          {/* Contact Form */}
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-8 md:p-12 rounded-2xl shadow-2xl">
            <div className="text-center mb-8">
              <h3 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Shift to Sustainable Solutions
              </h3>
              <p className="text-xl text-blue-100">
                Ready to make a change? Get in touch with us to learn more about implementing sustainable practices.
              </p>
            </div>

            <Card className="shadow-2xl max-w-3xl mx-auto">
              <CardContent className="p-8">
                {submitted ? (
                  <div className="text-center py-12">
                    <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                      <CheckCircle className="h-10 w-10 text-blue-600" />
                    </div>
                    <h4 className="text-2xl font-bold text-gray-900 mb-2">
                      Thank You!
                    </h4>
                    <p className="text-gray-600">
                      We've received your message and will be in touch soon.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="name" className="text-gray-700">
                          Full Name *
                        </Label>
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          required
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="John Doe"
                          className="mt-2"
                        />
                      </div>
                      <div>
                        <Label htmlFor="organization" className="text-gray-700">
                          Organization *
                        </Label>
                        <Input
                          id="organization"
                          name="organization"
                          type="text"
                          required
                          value={formData.organization}
                          onChange={handleChange}
                          placeholder="Company Name"
                          className="mt-2"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-gray-700">
                        Email Address *
                      </Label>
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="john@company.com"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="message" className="text-gray-700">
                        Message *
                      </Label>
                      <Textarea
                        id="message"
                        name="message"
                        required
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Tell us about your interest in sustainable solutions..."
                        className="mt-2 min-h-32"
                      />
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg"
                    >
                      Send Message
                    </Button>
                  </form>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
      </div>
    </div>
  );
};

export default HomePage;
