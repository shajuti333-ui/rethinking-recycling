#!/bin/bash

echo "🚀 GitHub Deployment Script"
echo "=============================="
echo ""
echo "This will push your code to GitHub repository: rethinking-recycling"
echo ""

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git is not installed. Please install Git first."
    echo "Download from: https://git-scm.com/downloads"
    exit 1
fi

# Initialize git
echo "📦 Initializing Git repository..."
git init

# Add all files
echo "📁 Adding files..."
git add .

# Commit
echo "💾 Creating commit..."
git commit -m "Initial commit - Rethinking Chemical Recycling website"

# Ask for GitHub username
echo ""
echo "Enter your GitHub username:"
read GITHUB_USERNAME

# Add remote
echo "🔗 Connecting to GitHub..."
git branch -M main
git remote add origin https://github.com/$GITHUB_USERNAME/rethinking-recycling.git

# Push to GitHub
echo "⬆️  Pushing to GitHub..."
git push -u origin main

echo ""
echo "✅ SUCCESS! Your code is now on GitHub!"
echo ""
echo "🌐 Next steps:"
echo "1. Go to: https://vercel.com/new"
echo "2. Click 'Import Git Repository'"
echo "3. Select 'rethinking-recycling'"
echo "4. Click 'Deploy'"
echo "5. Get your permanent FREE URL!"
echo ""

